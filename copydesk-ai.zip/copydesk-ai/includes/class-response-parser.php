<?php
/**
 * Response Parser
 *
 * Parses and validates AI responses.
 *
 * @package AI_Feedback
 */

namespace AI_Feedback;

/**
 * Response Parser class.
 */
class Response_Parser {


	/**
	 * Valid category values for feedback items.
	 */
	public const VALID_CATEGORIES = array( 'content', 'tone', 'flow', 'design' );

	/**
	 * Valid severity values for feedback items.
	 */
	public const VALID_SEVERITIES = array( 'suggestion', 'important', 'critical' );

	/**
	 * Required fields for each feedback item.
	 */
	public const REQUIRED_FEEDBACK_FIELDS = array( 'block_id', 'category', 'severity', 'title', 'feedback' );

	/**
	 * Optional fields for each feedback item.
	 */
	public const OPTIONAL_FEEDBACK_FIELDS = array( 'suggestion', 'quick_fix' );

	/**
	 * Maximum length of a quick fix's find and replace text.
	 *
	 * @var int
	 */
	public const MAX_QUICK_FIX_LENGTH = 200;

	/**
	 * Maximum character lengths for feedback fields.
	 */
	public const FIELD_MAX_LENGTHS = array(
		'summary'    => 500,
		'title'      => 50,
		'feedback'   => 300,
		'suggestion' => 200,
	);

	/**
	 * Severity weights used by calculate_priority().
	 */
	public const PRIORITY_SEVERITY_WEIGHTS = array(
		'critical'   => 100,
		'important'  => 50,
		'suggestion' => 10,
	);

	/**
	 * Category weights used by calculate_priority().
	 */
	public const PRIORITY_CATEGORY_WEIGHTS = array(
		'content' => 30,
		'flow'    => 20,
		'tone'    => 15,
		'design'  => 10,
	);

	/**
	 * Block-type weights used by calculate_priority().
	 *
	 * Blocks not listed here fall back to PRIORITY_BLOCK_DEFAULT.
	 */
	public const PRIORITY_BLOCK_WEIGHTS = array(
		'core/heading'   => 15,
		'core/list'      => 10,
		'core/quote'     => 10,
		'core/paragraph' => 5,
	);

	/**
	 * Default block-type weight when a block is not in PRIORITY_BLOCK_WEIGHTS.
	 */
	public const PRIORITY_BLOCK_DEFAULT = 5;

	/**
	 * Position bonus for the first block, reduced by PRIORITY_POSITION_STEP per block.
	 */
	public const PRIORITY_POSITION_MAX  = 25;
	public const PRIORITY_POSITION_STEP = 5;

	/**
	 * Score thresholds clients use to bucket priorities into high / medium / low.
	 */
	public const PRIORITY_HIGH_THRESHOLD   = 100;
	public const PRIORITY_MEDIUM_THRESHOLD = 50;

	/**
	 * Parse an AI response and extract validated feedback items with an optional summary.
	 *
	 * Given the raw AI response text, attempts to extract and decode JSON, validates and
	 * sanitizes feedback items, and enriches them with block metadata drawn from $blocks.
	 *
	 * @param  string $response        AI response text (may contain surrounding text; JSON is extracted).
	 * @param  array  $blocks          Original blocks used to validate `block_id` values and provide
	 *                                 enrichment (`name` and `index`) for validated items.
	 * @param  bool   $validate_schema If true, perform strict JSON schema validation and return
	 *                                 a WP_Error on schema or parse failures; if false, parsing
	 *                                 errors yield an empty result structure.
	 * @return array|\WP_Error On success, an array with keys:
	 *                         - `summary` (string): sanitized summary text.
	 *                         - `feedback` (array): list of validated, sanitized, and enriched feedback items.
	 *                         On schema validation failure (when $validate_schema is true), returns a WP_Error.
	 */
	public function parse_feedback( string $response, array $blocks, bool $validate_schema = false ) {
		// Build a map of valid block IDs for validation, including block name.
		$valid_block_ids = array();
		$block_info      = array();

		Logger::debug( sprintf( 'Parsing feedback, received %d blocks', count( $blocks ) ) );

		foreach ( $blocks as $index => $block ) {
			if ( ! empty( $block['clientId'] ) ) {
				$valid_block_ids[ $block['clientId'] ] = true;
				// Store block info for enriching feedback items.
				$block_info[ $block['clientId'] ] = array(
					'name'    => $block['name'] ?? '',
					'index'   => $index,
					'content' => is_array( $block ) && is_string( $block['content'] ?? null ) ? $block['content'] : '',
				);
				Logger::debug(
					sprintf(
						'Block %d: clientId=%s, name=%s',
						$index,
						$block['clientId'],
						$block['name'] ?? 'unknown'
					)
				);
			}
		}

		// Extract JSON from response (in case AI added text before/after).
		$json = $this->extract_json( $response );

		if ( empty( $json ) ) {
			if ( $validate_schema ) {
				return new \WP_Error(
					'invalid_json',
					__( 'Could not extract valid JSON from AI response.', 'copydesk-ai' )
				);
			}
			return array(
				'summary'  => '',
				'feedback' => array(),
			);
		}

		// Decode JSON.
		$data = json_decode( $json, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			if ( $validate_schema ) {
				return new \WP_Error(
					'json_parse_error',
					sprintf(
					/* translators: %s: JSON error message */
						__( 'JSON parse error: %s', 'copydesk-ai' ),
						json_last_error_msg()
					)
				);
			}
			return array(
				'summary'  => '',
				'feedback' => array(),
			);
		}

		// Perform schema validation if requested.
		if ( $validate_schema ) {
			$schema_result = $this->validate_schema( $data );
			if ( is_wp_error( $schema_result ) ) {
				return $schema_result;
			}
		}

		// Handle new format with summary and feedback.
		if ( is_array( $data ) && isset( $data['feedback'] ) ) {
			$summary        = $data['summary'] ?? '';
			$feedback_items = $data['feedback'];
		} elseif ( is_array( $data ) && isset( $data[0] ) ) {
			// Legacy format - array of feedback items.
			$summary        = '';
			$feedback_items = $data;
		} else {
			if ( $validate_schema ) {
				return new \WP_Error(
					'invalid_format',
					__( 'Response does not contain expected feedback format.', 'copydesk-ai' )
				);
			}
			return array(
				'summary'  => '',
				'feedback' => array(),
			);
		}

		// Parse and validate each feedback item.
		$parsed = array();
		foreach ( $feedback_items as $item ) {
			$validated = $this->validate_feedback_item( $item, $valid_block_ids, $block_info );
			if ( $validated ) {
				$validated['priority'] = $this->calculate_priority( $validated );
				$parsed[]              = $validated;
			}
		}

		Logger::debug( sprintf( 'Parsed %d valid feedback items', count( $parsed ) ) );

		// Group similar feedback items to reduce noise.
		$grouped = $this->group_similar_feedback( $parsed );

		Logger::debug( sprintf( 'Grouped into %d feedback items', count( $grouped ) ) );

		// Sort by priority so the most impactful feedback surfaces first.
		$grouped = $this->sort_by_priority( $grouped );

		return array(
			'summary'  => $this->sanitize_summary( $summary ),
			'feedback' => $grouped,
		);
	}

	/**
	 * Calculate a priority score for a single feedback item.
	 *
	 * Combines severity (largest factor), category, block type, and a small
	 * position bonus for early blocks. The score is bucketed by clients into
	 * high / medium / low using PRIORITY_*_THRESHOLD constants.
	 *
	 * Blocks without a known `block_name` still add PRIORITY_BLOCK_DEFAULT, so
	 * the score always includes a block-type weight.
	 *
	 * @param  array<string, mixed> $item Validated feedback item. Expected keys: `severity`,
	 *                                    `category`, optional `block_name`, optional `block_index`.
	 * @return int Priority score (higher means more important).
	 */
	public function calculate_priority( array $item ): int {
		$severity   = is_string( $item['severity'] ?? null ) ? $item['severity'] : '';
		$category   = is_string( $item['category'] ?? null ) ? $item['category'] : '';
		$block_name = is_string( $item['block_name'] ?? null ) ? $item['block_name'] : '';

		$score  = self::PRIORITY_SEVERITY_WEIGHTS[ $severity ] ?? 0;
		$score += self::PRIORITY_CATEGORY_WEIGHTS[ $category ] ?? 0;
		$score += self::PRIORITY_BLOCK_WEIGHTS[ $block_name ] ?? self::PRIORITY_BLOCK_DEFAULT;

		// Early blocks get a decreasing bonus (25, 20, 15, 10, 5, then 0).
		if ( isset( $item['block_index'] ) && is_int( $item['block_index'] ) ) {
			$score += max( 0, self::PRIORITY_POSITION_MAX - ( $item['block_index'] * self::PRIORITY_POSITION_STEP ) );
		}

		return $score;
	}

	/**
	 * Sort feedback items by priority score, highest first.
	 *
	 * Items without a `priority` key are treated as zero. Ties are broken by
	 * `block_index` so equal-priority items follow document order; `usort` is
	 * stable on PHP 8+, so remaining ties keep their original order.
	 *
	 * @param  array<int, array<string, mixed>> $feedback Feedback items, each expected to have an integer `priority`.
	 * @return array<int, array<string, mixed>> Feedback items sorted by descending priority.
	 */
	public function sort_by_priority( array $feedback ): array {
		usort(
			$feedback,
			static function ( array $a, array $b ): int {
				$pa = is_int( $a['priority'] ?? null ) ? $a['priority'] : 0;
				$pb = is_int( $b['priority'] ?? null ) ? $b['priority'] : 0;
				if ( $pa !== $pb ) {
					return $pb <=> $pa;
				}
				return self::get_document_position( $a ) <=> self::get_document_position( $b );
			}
		);

		return $feedback;
	}

	/**
	 * Document position of a feedback item, used to break priority ties.
	 *
	 * Groups use their earliest member block, matching getDocumentPosition()
	 * in src/utils/priority.js.
	 *
	 * @param  array<string, mixed> $item Feedback item.
	 * @return int Block index, or PHP_INT_MAX when unknown.
	 */
	private static function get_document_position( array $item ): int {
		$indexes = is_array( $item['block_indexes'] ?? null ) ? array_filter( $item['block_indexes'], 'is_int' ) : array();
		if ( ! empty( $indexes ) ) {
			return min( $indexes );
		}
		return is_int( $item['block_index'] ?? null ) ? $item['block_index'] : PHP_INT_MAX;
	}

	/**
	 * Extract JSON from response text.
	 *
	 * Sometimes AI adds explanation text before/after JSON.
	 * This extracts the JSON object or array.
	 *
	 * @param  string $response Response text.
	 * @return string JSON string or empty.
	 */
	private function extract_json( string $response ): string {
		$response = trim( $response );

		// Try to find JSON object first (new format with summary).
		if ( preg_match( '/\{.*\}/s', $response, $matches ) ) {
			// Verify it contains our expected structure.
			$test = json_decode( $matches[0], true );
			if ( is_array( $test ) && ( isset( $test['feedback'] ) || isset( $test['summary'] ) ) ) {
				return $matches[0];
			}
		}

		// Try to find JSON array (legacy format).
		if ( preg_match( '/\[.*\]/s', $response, $matches ) ) {
			return $matches[0];
		}

		// If response starts with { or [, return as is.
		if ( strpos( $response, '{' ) === 0 || strpos( $response, '[' ) === 0 ) {
			return $response;
		}

		return '';
	}

	/**
	 * Validate and sanitize a single feedback item, enriching it with block metadata when available.
	 *
	 * Ensures the item contains a valid `block_id` present in `$valid_block_ids`, includes the required
	 * fields (`category`, `severity`, `title`, `feedback`), and that `category` and `severity` are
	 * allowed values. When valid, returns a sanitized array containing `block_id`, `category`, `severity`,
	 * `title`, and `feedback`; includes `block_name` and `block_index` from `$block_info` when available,
	 * and includes a sanitized `suggestion` if provided.
	 *
	 * @param  mixed $item            Feedback item data.
	 * @param  array $valid_block_ids Map of valid block IDs.
	 * @param  array $block_info      Map of block IDs to their info (name, index).
	 * @return array<string, mixed>|null Array of validated and sanitized fields on success, `null` if the item is invalid.
	 */
	private function validate_feedback_item( $item, array $valid_block_ids, array $block_info = array() ): ?array {
		// Must be an array.
		if ( ! is_array( $item ) ) {
			Logger::debug( 'Feedback item is not an array, skipping' );
			return null;
		}

		// Get block_id (new format) or block_index (legacy).
		$block_id = $item['block_id'] ?? null;

		// If no block_id, skip this item.
		if ( empty( $block_id ) ) {
			Logger::debug( 'Feedback item has no block_id, skipping' );
			return null;
		}

		// Validate block_id exists in our valid blocks.
		if ( ! isset( $valid_block_ids[ $block_id ] ) ) {
			Logger::debug( sprintf( 'Block ID %s not found in valid blocks, skipping', $block_id ) );
			return null;
		}

		// Required fields.
		$required = array( 'category', 'severity', 'title', 'feedback' );
		foreach ( $required as $field ) {
			if ( ! isset( $item[ $field ] ) ) {
				Logger::debug( sprintf( 'Feedback item missing required field: %s', $field ) );
				return null;
			}
		}

		// Validate category.
		if ( ! in_array( $item['category'], self::VALID_CATEGORIES, true ) ) {
			Logger::debug( sprintf( 'Invalid category: %s', $item['category'] ) );
			return null;
		}

		// Validate severity.
		if ( ! in_array( $item['severity'], self::VALID_SEVERITIES, true ) ) {
			Logger::debug( sprintf( 'Invalid severity: %s', $item['severity'] ) );
			return null;
		}

		// Build validated item.
		$validated = array(
			'block_id' => sanitize_text_field( $block_id ),
			'category' => sanitize_text_field( $item['category'] ),
			'severity' => sanitize_text_field( $item['severity'] ),
			'title'    => $this->sanitize_title( $item['title'] ),
			'feedback' => $this->sanitize_feedback( $item['feedback'] ),
		);

		// Add block name and index from block_info if available.
		if ( isset( $block_info[ $block_id ] ) ) {
			$validated['block_name']  = $block_info[ $block_id ]['name'] ?? '';
			$validated['block_index'] = $block_info[ $block_id ]['index'] ?? 0;
			Logger::debug(
				sprintf(
					'Enriched feedback item with block_name=%s, block_index=%d',
					$validated['block_name'],
					$validated['block_index']
				)
			);
		}

		// Optional suggestion field.
		if ( isset( $item['suggestion'] ) && ! empty( $item['suggestion'] ) ) {
			$validated['suggestion'] = $this->sanitize_feedback( $item['suggestion'] );
		}

		// Optional quick fix, kept only when it applies cleanly to the block.
		if ( isset( $item['quick_fix'] ) ) {
			$info          = is_string( $block_id ) ? ( $block_info[ $block_id ] ?? null ) : null;
			$block_content = is_array( $info ) && is_string( $info['content'] ?? null ) ? $info['content'] : '';
			$quick_fix     = $this->validate_quick_fix( $item['quick_fix'], $block_content );
			if ( null !== $quick_fix ) {
				$validated['quick_fix'] = $quick_fix;
			}
		}

		return $validated;
	}

	/**
	 * Validate a quick fix against the block it targets.
	 *
	 * A quick fix is a plain text find/replace. It is dropped if it contains
	 * markup, or unless `find` appears exactly once in the block's text, so
	 * applying it is unambiguous.
	 *
	 * @param  mixed  $quick_fix     Quick fix from the AI response.
	 * @param  string $block_content Plain text content of the target block.
	 * @return array{find: string, replace: string}|null Sanitized quick fix, or null if unusable.
	 */
	public function validate_quick_fix( $quick_fix, string $block_content ): ?array {
		if ( ! is_array( $quick_fix ) ) {
			return null;
		}

		$find    = $quick_fix['find'] ?? null;
		$replace = $quick_fix['replace'] ?? '';

		if ( ! is_string( $find ) || ! is_string( $replace ) ) {
			return null;
		}

		// Plain text only; markup can't be matched against the block's text.
		// Reject rather than strip, since stripping also trims whitespace that
		// may be part of the intended edit.
		if ( str_contains( $find, '<' ) || str_contains( $replace, '<' ) ) {
			return null;
		}

		if ( '' === trim( $find ) || $find === $replace ) {
			return null;
		}

		if ( mb_strlen( $find ) > self::MAX_QUICK_FIX_LENGTH || mb_strlen( $replace ) > self::MAX_QUICK_FIX_LENGTH ) {
			return null;
		}

		if ( 1 !== $this->count_quick_fix_matches( $find, $block_content ) ) {
			Logger::debug( 'Quick fix text not found exactly once in block, dropping it' );
			return null;
		}

		return array(
			'find'    => $find,
			'replace' => $replace,
		);
	}

	/**
	 * Count matches of a quick fix's text in block content.
	 *
	 * Text that starts or ends with a letter or digit only matches at a word
	 * boundary there, so "cat" doesn't match inside "concatenate". The editor
	 * uses the same rule (src/utils/quick-fix.js).
	 *
	 * @param  string $find    Text to find.
	 * @param  string $content Block content.
	 * @return int Number of matches.
	 */
	private function count_quick_fix_matches( string $find, string $content ): int {
		$pattern = preg_quote( $find, '/' );

		if ( preg_match( '/^[\p{L}\p{N}]/u', $find ) ) {
			$pattern = '(?<![\p{L}\p{N}])' . $pattern;
		}

		if ( preg_match( '/[\p{L}\p{N}]$/u', $find ) ) {
			$pattern .= '(?![\p{L}\p{N}])';
		}

		$count = preg_match_all( '/' . $pattern . '/u', $content );

		return false === $count ? 0 : $count;
	}

	/**
	 * Sanitize summary text.
	 *
	 * @param  string $summary Summary text.
	 * @return string Sanitized summary.
	 */
	private function sanitize_summary( string $summary ): string {
		$summary = wp_kses_post( $summary );

		// Truncate to 500 characters (generous for summary).
		if ( mb_strlen( $summary, 'UTF-8' ) > 500 ) {
			$summary = mb_substr( $summary, 0, 497, 'UTF-8' ) . '...';
		}

		return $summary;
	}

	/**
	 * Sanitize title text.
	 *
	 * @param  string $title Title text.
	 * @return string Sanitized title.
	 */
	private function sanitize_title( string $title ): string {
		$title = sanitize_text_field( $title );

		// Truncate to 50 characters.
		if ( mb_strlen( $title, 'UTF-8' ) > 50 ) {
			$title = mb_substr( $title, 0, 47, 'UTF-8' ) . '...';
		}

		return $title;
	}

	/**
	 * Sanitize feedback text.
	 *
	 * Allows basic formatting tags.
	 *
	 * @param  string $feedback Feedback text.
	 * @return string Sanitized feedback.
	 */
	private function sanitize_feedback( string $feedback ): string {
		// Allow basic formatting.
		$allowed_tags = array(
			'strong' => array(),
			'em'     => array(),
			'code'   => array(),
			'br'     => array(),
		);

		$feedback = wp_kses( $feedback, $allowed_tags );

		// Truncate to 300 characters (increased from 200 to be more flexible).
		if ( mb_strlen( $feedback, 'UTF-8' ) > 300 ) {
			$feedback = mb_substr( $feedback, 0, 297, 'UTF-8' ) . '...';
		}

		return $feedback;
	}

	/**
	 * Produce aggregated counts and flags for a set of parsed feedback items.
	 *
	 * @param  array $feedback_items Parsed feedback items. Each item is expected to include at least the `category` and `severity` keys.
	 * @return array{
	 *     total_notes: int,
	 *     by_category: array{content:int, tone:int, flow:int, design:int},
	 *     by_severity: array{suggestion:int, important:int, critical:int},
	 *     has_critical: bool
	 * } Summary data with total counts by category and severity, and a boolean indicating presence of any critical items.
	 */
	public function get_feedback_summary( array $feedback_items ): array {
		$summary = array(
			'total_notes'  => count( $feedback_items ),
			'by_category'  => array(
				'content' => 0,
				'tone'    => 0,
				'flow'    => 0,
				'design'  => 0,
			),
			'by_severity'  => array(
				'suggestion' => 0,
				'important'  => 0,
				'critical'   => 0,
			),
			'has_critical' => false,
		);

		foreach ( $feedback_items as $item ) {
			// Count by category.
			if ( isset( $summary['by_category'][ $item['category'] ] ) ) {
				++$summary['by_category'][ $item['category'] ];
			}

			// Count by severity.
			if ( isset( $summary['by_severity'][ $item['severity'] ] ) ) {
				++$summary['by_severity'][ $item['severity'] ];
			}

			// Track if any critical items exist.
			if ( 'critical' === $item['severity'] ) {
				$summary['has_critical'] = true;
			}
		}

		return $summary;
	}

	/**
	 * Validates the decoded JSON response structure against the expected schema.
	 *
	 * Performs structural and type checks only; does not perform semantic validations
	 * (for example, it does not verify that referenced block IDs exist).
	 *
	 * @param  mixed $data Decoded JSON data to validate.
	 * @return true|\WP_Error `true` if the data conforms to the schema, a `WP_Error`
	 *                      containing one or more validation errors otherwise.
	 */
	public function validate_schema( $data ) {
		$errors = new \WP_Error();

		// Must be an array/object.
		if ( ! is_array( $data ) ) {
			$errors->add(
				'invalid_type',
				__( 'Response must be a JSON object.', 'copydesk-ai' ),
				array( 'path' => '$' )
			);
			return $errors;
		}

		// Check for required 'feedback' field.
		if ( ! isset( $data['feedback'] ) ) {
			$errors->add(
				'missing_field',
				__( 'Response must contain a "feedback" array.', 'copydesk-ai' ),
				array( 'path' => '$.feedback' )
			);
		} elseif ( ! is_array( $data['feedback'] ) ) {
			$errors->add(
				'invalid_type',
				__( 'The "feedback" field must be an array.', 'copydesk-ai' ),
				array( 'path' => '$.feedback' )
			);
		} else {
			// Validate each feedback item.
			foreach ( $data['feedback'] as $index => $item ) {
				$item_errors = $this->validate_feedback_item_schema( $item, $index );
				if ( is_wp_error( $item_errors ) ) {
					foreach ( $item_errors->get_error_codes() as $code ) {
						$error_data = $item_errors->get_error_data( $code );
						foreach ( $item_errors->get_error_messages( $code ) as $message ) {
								$errors->add( $code, $message, $error_data );
						}
					}
				}
			}
		}

		// Validate optional summary field.
		if ( isset( $data['summary'] ) && ! is_string( $data['summary'] ) ) {
			$errors->add(
				'invalid_type',
				__( 'The "summary" field must be a string.', 'copydesk-ai' ),
				array( 'path' => '$.summary' )
			);
		}

		// Return true if no errors, otherwise return WP_Error.
		if ( ! $errors->has_errors() ) {
			return true;
		}

		return $errors;
	}

	/**
	 * Validates a single feedback item against the parser's JSON schema rules.
	 *
	 * Ensures the item is an object/array, contains all required string fields, enforces allowed
	 * values for `category` and `severity`, and checks the optional `suggestion` is a string.
	 *
	 * @param  mixed $item  Feedback item to validate.
	 * @param  int   $index Index of the item in the feedback array (used to build error paths).
	 * @return true|\WP_Error `true` if the item is valid, or a `\WP_Error` containing one or more
	 *                        validation errors with `path` metadata indicating the failing field.
	 */
	private function validate_feedback_item_schema( $item, int $index ) {
		$errors = new \WP_Error();
		$path   = '$.feedback[' . $index . ']';

		// Must be an array/object.
		if ( ! is_array( $item ) ) {
			$errors->add(
				'invalid_type',
				sprintf(
				/* translators: %d: item index */
					__( 'Feedback item %d must be an object.', 'copydesk-ai' ),
					$index
				),
				array( 'path' => $path )
			);
			return $errors;
		}

		// Check required fields.
		foreach ( self::REQUIRED_FEEDBACK_FIELDS as $field ) {
			if ( ! isset( $item[ $field ] ) ) {
				$errors->add(
					'missing_field',
					sprintf(
					/* translators: 1: field name, 2: item index */
						__( 'Feedback item %2$d is missing required field "%1$s".', 'copydesk-ai' ),
						$field,
						$index
					),
					array( 'path' => $path . '.' . $field )
				);
			} elseif ( ! is_string( $item[ $field ] ) ) {
				$errors->add(
					'invalid_type',
					sprintf(
					/* translators: 1: field name, 2: item index */
						__( 'Field "%1$s" in feedback item %2$d must be a string.', 'copydesk-ai' ),
						$field,
						$index
					),
					array( 'path' => $path . '.' . $field )
				);
			}
		}

		// Validate category enum.
		if ( isset( $item['category'] ) && is_string( $item['category'] ) ) {
			if ( ! in_array( $item['category'], self::VALID_CATEGORIES, true ) ) {
				$errors->add(
					'invalid_enum',
					sprintf(
					/* translators: 1: invalid value, 2: valid values, 3: item index */
						__( 'Invalid category "%1$s" in item %3$d. Must be one of: %2$s.', 'copydesk-ai' ),
						$item['category'],
						implode( ', ', self::VALID_CATEGORIES ),
						$index
					),
					array( 'path' => $path . '.category' )
				);
			}
		}

		// Validate severity enum.
		if ( isset( $item['severity'] ) && is_string( $item['severity'] ) ) {
			if ( ! in_array( $item['severity'], self::VALID_SEVERITIES, true ) ) {
				$errors->add(
					'invalid_enum',
					sprintf(
					/* translators: 1: invalid value, 2: valid values, 3: item index */
						__( 'Invalid severity "%1$s" in item %3$d. Must be one of: %2$s.', 'copydesk-ai' ),
						$item['severity'],
						implode( ', ', self::VALID_SEVERITIES ),
						$index
					),
					array( 'path' => $path . '.severity' )
				);
			}
		}

		// A malformed quick_fix is dropped later without rejecting the item.

		// Validate optional suggestion field type.
		if ( isset( $item['suggestion'] ) && ! is_string( $item['suggestion'] ) ) {
			$errors->add(
				'invalid_type',
				sprintf(
				/* translators: %d: item index */
					__( 'Field "suggestion" in feedback item %d must be a string.', 'copydesk-ai' ),
					$index
				),
				array( 'path' => $path . '.suggestion' )
			);
		}

		if ( ! $errors->has_errors() ) {
			return true;
		}

		return $errors;
	}

	/**
	 * Convert a WP_Error of validation failures into a human-readable multi-line string.
	 *
	 * Each line is formatted as "[code] message (at path)" when path information is present.
	 *
	 * @param  \WP_Error $errors Validation errors; individual error data may include a 'path' key.
	 * @return string Multi-line formatted error report.
	 */
	public function format_validation_errors( \WP_Error $errors ): string {
		$output = array();

		foreach ( $errors->get_error_codes() as $code ) {
			$messages = $errors->get_error_messages( $code );
			foreach ( $messages as $message ) {
				$data     = $errors->get_error_data( $code );
				$path     = is_array( $data ) && isset( $data['path'] ) ? $data['path'] : '';
				$output[] = sprintf(
					'[%s] %s%s',
					$code,
					$message,
					$path ? ' (at ' . $path . ')' : ''
				);
			}
		}

		return implode( "\n", $output );
	}

	/**
	 * Group similar feedback items to reduce noise.
	 *
	 * Groups feedback items with the same category and similar titles together.
	 * This helps users identify patterns and fix similar issues more efficiently.
	 *
	 * @param  array<int, array<string, mixed>> $feedback Parsed feedback items.
	 * @return array<int, array<string, mixed>> Grouped feedback items with is_group, count, and block_ids fields.
	 */
	public function group_similar_feedback( array $feedback ): array {
		if ( empty( $feedback ) ) {
			return array();
		}

		$groups = array();

		foreach ( $feedback as $item ) {
			// Create a key based on category and normalized title.
			$key = $this->create_group_key( $item );

			if ( isset( $groups[ $key ] ) ) {
				// Add to existing group.
				$groups[ $key ]['block_ids'][] = $item['block_id'];
				++$groups[ $key ]['count'];
				// Keep highest severity.
				if ( $this->severity_rank( $item['severity'] ) >
					$this->severity_rank( $groups[ $key ]['severity'] ) ) {
					$groups[ $key ]['severity'] = $item['severity'];
				}
				// Keep highest priority across grouped items.
				if ( isset( $item['priority'] ) && $item['priority'] > ( $groups[ $key ]['priority'] ?? 0 ) ) {
					$groups[ $key ]['priority'] = $item['priority'];
				}
				// Preserve block_name and block_index arrays.
				if ( ! empty( $item['block_name'] ) ) {
					$groups[ $key ]['block_names'][] = $item['block_name'];
				}
				if ( isset( $item['block_index'] ) ) {
					$groups[ $key ]['block_indexes'][] = $item['block_index'];
				}
			} else {
				// Create new group.
				$groups[ $key ] = array_merge(
					$item,
					array(
						'block_ids'      => array( $item['block_id'] ),
						'block_names'    => ! empty( $item['block_name'] ) ? array( $item['block_name'] ) : array(),
						'block_indexes'  => isset( $item['block_index'] ) ? array( $item['block_index'] ) : array(),
						'count'          => 1,
						'is_group'       => false,
						'original_title' => $item['title'],
					)
				);
			}
		}

		// Mark items that became groups and update their titles.
		foreach ( $groups as &$group ) {
			if ( $group['count'] > 1 ) {
				// A quick fix targets one block, so it can't apply to a group.
				unset( $group['quick_fix'] );
				$group['is_group'] = true;
				$group['title']    = sprintf(
					/* translators: 1: original title, 2: occurrence count */
					__( '%1$s (%2$d occurrences)', 'copydesk-ai' ),
					$group['original_title'],
					$group['count']
				);
			}
		}

		return array_values( $groups );
	}

	/**
	 * Create a normalized key for grouping feedback items.
	 *
	 * Generates a grouping key based on category and normalized title.
	 * Normalization converts to lowercase and replaces spaces with underscores
	 * while removing other special characters.
	 *
	 * @param  array $item Feedback item with category and title.
	 * @return string Grouping key.
	 */
	private function create_group_key( array $item ): string {
		// Normalize title for grouping.
		$normalized = strtolower( $item['title'] );
		// Replace spaces and hyphens with underscores to preserve word boundaries.
		$normalized = str_replace( array( ' ', '-' ), '_', $normalized );
		// Remove special characters but keep alphanumeric and underscores.
		$normalized = preg_replace( '/[^a-z0-9_]/', '', $normalized );

		return $item['category'] . ':' . $normalized;
	}

	/**
	 * Get numeric rank for severity level.
	 *
	 * Returns a numeric value for each severity level to enable comparison.
	 * Higher numbers indicate higher severity.
	 *
	 * @param  string $severity Severity level (suggestion, important, critical).
	 * @return int Numeric rank (1-3, or 0 for unknown).
	 */
	private function severity_rank( string $severity ): int {
		$ranks = array(
			'suggestion' => 1,
			'important'  => 2,
			'critical'   => 3,
		);

		return $ranks[ $severity ] ?? 0;
	}
}
